
insert into EMPLOYEE (forename,surname,salary,gender) values('Yamini','V','20000','Female');
