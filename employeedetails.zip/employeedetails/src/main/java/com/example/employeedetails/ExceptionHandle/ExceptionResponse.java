package com.example.employeedetails.ExceptionHandle;
public class ExceptionResponse {
	private String errormessage;
	private String details;
	
	public ExceptionResponse(String message, String description) {

	}
	public String getErrorMessage() {
		return errormessage;
	}
	public void setErrorMessage(String Errormessage) {
		errormessage = Errormessage;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
	
}
