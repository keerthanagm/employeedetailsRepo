package com.example.employeedetails.Entity;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="EMPLOYEE")
public class Employee {
	 @Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String forename;
	private String surname;
	private int salary;
	private String Gender;
	 @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getForename() {
		return forename;
	}
	public void setForename(String forename) {
		this.forename = forename;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}

	public Employee() {
		super();
	}
	public Employee(int id, String forename, String surname, int salary, String Gender) {
		super();
		this.id = id;
		this.forename = forename;
		this.surname = surname;
		this.salary = salary;
		this.Gender= Gender;
	}
	

}

